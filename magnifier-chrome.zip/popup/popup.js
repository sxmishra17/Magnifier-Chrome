// popup.js – Settings panel with multi-language localization (Chrome MV3)

(function () {
  "use strict";

  const zoomSlider    = document.getElementById("zoomSlider");
  const zoomBadge     = document.getElementById("zoomBadge");
  const sizeSlider    = document.getElementById("sizeSlider");
  const sizeBadge     = document.getElementById("sizeBadge");
  const enableToggle  = document.getElementById("enableToggle");
  const posRadios     = document.querySelectorAll("input[name='lensPos']");
  const shapeRadios   = document.querySelectorAll("input[name='lensShape']");
  const openPdfViewer = document.getElementById("openPdfViewer");
  const langSelect    = document.getElementById("langSelect");

  const SIZE_KEYS    = { 1: "small", 2: "medium", 3: "large" };
  const SIZE_TO_INT  = { small: 1, medium: 2, large: 3 };
  const INT_TO_SIZE  = { 1: "small", 2: "medium", 3: "large" };

  let currentSettings = {
    zoom: 1.5,
    lensSize: "medium",
    lensPosition: "right",
    lensShape: "rect",
    language: "auto"
  };

  // Populate Language dropdown
  if (langSelect && window.I18N) {
    langSelect.innerHTML = "";
    for (const [code, name] of Object.entries(window.I18N.SUPPORTED_LANGUAGES)) {
      const opt = document.createElement("option");
      opt.value = code;
      opt.textContent = name;
      langSelect.appendChild(opt);
    }
  }

  function getTargetTab(cb) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0] && tabs[0].id) {
        cb(tabs[0]);
      } else {
        chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs2) => {
          cb(tabs2 && tabs2[0] ? tabs2[0] : null);
        });
      }
    });
  }

  // ── Load current settings on popup open ─────────────────────────────────

  getTargetTab((tab) => {
    const tabId = tab ? tab.id : null;
    const fromStorage = chrome.storage.sync.get({
      zoom: 1.5,
      lensSize: "medium",
      lensPosition: "right",
      lensShape: "rect",
      language: "auto",
      enabled: false
    });
    const fromBg = tabId != null
      ? chrome.runtime.sendMessage({ type: "get-tab-enabled", tabId }).catch(() => ({ enabled: false }))
      : Promise.resolve({ enabled: false });

    Promise.all([fromStorage, fromBg]).then(([s, bg]) => {
      currentSettings = s;

      // Apply language
      if (window.I18N) {
        window.I18N.setLanguage(s.language || "auto");
        if (langSelect) langSelect.value = s.language || "auto";
        applyTranslations();
      }

      zoomSlider.value      = s.zoom;
      enableToggle.checked  = (bg && bg.enabled !== undefined) ? !!bg.enabled : !!s.enabled;
      zoomBadge.textContent = formatZoom(s.zoom);
      updateSliderTrack(s.zoom);

      const sizeInt       = SIZE_TO_INT[s.lensSize] || 2;
      sizeSlider.value    = sizeInt;
      updateSizeBadge(sizeInt);
      updateSizeTrack(sizeInt);

      posRadios.forEach((r)  => { r.checked = r.value === s.lensPosition; });
      shapeRadios.forEach((r) => { r.checked = r.value === s.lensShape; });
    }).catch(() => {});
  });

  // ── Apply Translations ──────────────────────────────────────────────────

  function applyTranslations() {
    if (!window.I18N) return;
    const t = window.I18N.t;

    const setTxt = (id, key) => {
      const el = document.getElementById(id);
      if (el) el.textContent = t(key);
    };

    setTxt("txtAppTitle", "appTitle");
    setTxt("txtSubtitle", "subtitle");
    setTxt("txtZoomLevel", "zoomLevel");
    setTxt("txtLensSize", "lensSize");
    setTxt("txtSizeSmall", "small");
    setTxt("txtSizeMedium", "medium");
    setTxt("txtSizeLarge", "large");
    setTxt("txtLensShape", "lensShape");
    setTxt("txtCircle", "circle");
    setTxt("txtRectangle", "rectangle");
    setTxt("txtLensPos", "lensPosition");
    setTxt("txtLanguage", "language");
    setTxt("txtPressHotkey", "pressHotkey");
    setTxt("txtDownloadDesktop", "downloadDesktop");
    setTxt("txtSavedAuto", "savedAuto");
    if (openPdfViewer) openPdfViewer.textContent = t("openPdfViewer");

    const curSizeInt = parseInt(sizeSlider.value, 10) || 2;
    updateSizeBadge(curSizeInt);
  }

  function updateSizeBadge(sizeInt) {
    const key = SIZE_KEYS[sizeInt] || "medium";
    if (window.I18N) {
      sizeBadge.textContent = window.I18N.t(key);
    }
  }

  // ── Language Selector ────────────────────────────────────────────────────

  if (langSelect) {
    langSelect.addEventListener("change", () => {
      const lang = langSelect.value;
      currentSettings.language = lang;
      if (window.I18N) {
        window.I18N.setLanguage(lang);
        applyTranslations();
      }
      saveAndSend("language", lang);
    });
  }

  // ── Zoom slider ──────────────────────────────────────────────────────────

  zoomSlider.addEventListener("input", () => {
    const zoom = parseFloat(zoomSlider.value);
    zoomBadge.textContent = formatZoom(zoom);
    updateSliderTrack(zoom);
    saveAndSend("zoom", zoom);
  });

  // ── Lens size slider ─────────────────────────────────────────────────────

  sizeSlider.addEventListener("input", () => {
    const val = parseInt(sizeSlider.value, 10);
    updateSizeBadge(val);
    updateSizeTrack(val);
    saveAndSend("lensSize", INT_TO_SIZE[val]);
  });

  // ── Lens position ────────────────────────────────────────────

  posRadios.forEach((r) => {
    r.addEventListener("change", () => {
      saveAndSend("lensPosition", r.value);
    });
  });

  // ── Lens shape ───────────────────────────────────────────────

  shapeRadios.forEach((r) => {
    r.addEventListener("change", () => {
      saveAndSend("lensShape", r.value);
    });
  });

  // ── Enable / disable toggle ──────────────────────────────────────────────

  enableToggle.addEventListener("change", () => {
    const isEnabled = enableToggle.checked;
    currentSettings.enabled = isEnabled;

    // 1. Sync to storage
    chrome.storage.sync.set({ enabled: isEnabled }).catch(() => {});

    // 2. Direct message & script injection fallback for target tab
    getTargetTab((tab) => {
      if (!tab || !tab.id) return;
      const tabId = tab.id;

      // Send to content script directly
      chrome.tabs.sendMessage(tabId, {
        type: "settings-update",
        patch: { enabled: isEnabled }
      }).catch(() => {
        // If content script was not yet injected, inject dynamically
        if (chrome.scripting) {
          chrome.scripting.executeScript({
            target: { tabId },
            files: ["content.js"]
          }).then(() => {
            chrome.scripting.insertCSS({
              target: { tabId },
              files: ["content.css"]
            }).catch(() => {});
            chrome.tabs.sendMessage(tabId, {
              type: "settings-update",
              patch: { enabled: isEnabled }
            }).catch(() => {});
          }).catch(() => {});
        }
      });

      // Also sync background state
      chrome.runtime.sendMessage({
        type: "set-tab-enabled",
        tabId,
        enabled: isEnabled
      }).catch(() => {});
    });

    // 3. When turning ON, close popup after a brief moment so user immediately sees the lens
    if (isEnabled) {
      setTimeout(() => {
        window.close();
      }, 180);
    }
  });

  // ── Open custom PDF viewer ─────────────────────────────────────────────

  if (openPdfViewer) {
    openPdfViewer.addEventListener("click", () => {
      const url = chrome.runtime.getURL("pdf-viewer/viewer.html");
      chrome.tabs.create({ url });
      window.close();
    });
  }

  // ── Direct download desktop executable zip (Magnifier.exe) ────────────────

  const downloadDesktopBtn = document.getElementById("downloadDesktopBtn");
  if (downloadDesktopBtn) {
    downloadDesktopBtn.addEventListener("click", () => {
      const directUrl = "https://raw.githubusercontent.com/sxmishra17/Magnifier-Chrome/main/Magnifier-Desktop.zip";
      const a = document.createElement("a");
      a.href = directUrl;
      a.download = "Magnifier-Desktop.zip";
      a.target = "_blank";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    });
  }

  // ── Open What's New Release Notes page ──────────────────────────────────

  const btnWhatsNew = document.getElementById("btnWhatsNew");
  if (btnWhatsNew) {
    btnWhatsNew.addEventListener("click", () => {
      const url = chrome.runtime.getURL("whats-new/whats-new.html");
      chrome.tabs.create({ url });
      window.close();
    });
  }

  // ── Company website ──────────────────────────────────────────────────────

  const btnCompanyWebsite = document.getElementById("btnCompanyWebsite");
  if (btnCompanyWebsite) {
    btnCompanyWebsite.addEventListener("click", () => {
      chrome.tabs.create({ url: "https://yuvatechsolutionsusa.com" });
      window.close();
    });
  }

  // ── Donate via PayPal ────────────────────────────────────────────────────

  const btnDonatePaypal = document.getElementById("btnDonatePaypal");
  if (btnDonatePaypal) {
    btnDonatePaypal.addEventListener("click", () => {
      const url = "https://www.paypal.com/donate/?business=YMZRV5ZW4QJ8U&no_recurring=0&item_name=I+love+to+serve+the+community+for+betterment.+A+small+contribution+can+get+the+development+going+free+of+charge.&currency_code=USD";
      chrome.tabs.create({ url });
      window.close();
    });
  }

  // ── Buy Me a Coffee ──────────────────────────────────────────────────────

  const btnDonateBmc = document.getElementById("btnDonateBmc");
  if (btnDonateBmc) {
    btnDonateBmc.addEventListener("click", () => {
      chrome.tabs.create({ url: "https://buymeacoffee.com/satishmishra17" });
      window.close();
    });
  }

  // ── Helpers ──────────────────────────────────────────────────────────────

  function saveAndSend(key, value) {
    chrome.storage.sync.set({ [key]: value }).catch(() => {});

    getTargetTab((tab) => {
      if (!tab || !tab.id) return;
      chrome.tabs
        .sendMessage(tab.id, {
          type: "settings-update",
          patch: { [key]: value },
        })
        .catch(() => {});
    });
  }

  function formatZoom(val) {
    const n = parseFloat(val);
    return (Number.isInteger(n) ? n : n.toFixed(1)) + "×";
  }

  function updateSliderTrack(val) {
    const pct = ((val - 1) / 9) * 100;
    zoomSlider.style.setProperty("--pct", pct + "%");
  }

  function updateSizeTrack(val) {
    const pct = ((val - 1) / 2) * 100;
    sizeSlider.style.setProperty("--pct", pct + "%");
  }
})();
